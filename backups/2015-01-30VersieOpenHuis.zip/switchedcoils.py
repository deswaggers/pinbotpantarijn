# -------------------------
# Switched Coils Control Mode - System 11
# myPinballs Jan 2014
#
# Copyright (C) 2013 myPinballs, Orange Cloud Software Ltd
# Aangepast Steven van der Staaij en Jelle Besseling voor Pinbot/Starwars
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
# -------------------------

import time
from time import time
import procgame
import locale
import logging
from procgame import *


base_path = "C:\P-ROC\pyprocgame-master/"
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"

class SwitchedCoils(game.Mode):

	def __init__(self, game, priority):
                super(SwitchedCoils, self).__init__(game, priority)

                self.ACCoilInProgress = False
                self.ACNameArray = ['outhole_knocker','trough','Ejecthole_LeftInsBFlash','Drops_RightInsBFlash','RampRaise_LowPlFlash','RampLow_EnergyFlash','Lejecthole_LeftPlFlash','Rejecthole_SunFlash']
##                self.ACNameArray.append('outholeKicker_flasher1')
##                self.ACNameArray.append('ballReleaseShooterLane_flasher2')
##                self.ACNameArray.append('upKicker_flasher3')
##                self.ACNameArray.append('unusedC4_flasher4')
##                self.ACNameArray.append('upperEject_flasher5')
##                self.ACNameArray.append('knocker_flasher6')
##                self.ACNameArray.append('lowerEject_flasher7')
##                self.ACNameArray.append('unusedC8_flasher8')

        def mode_started(self):
            pass

############################
	#### AC Relay Functions ####
	############################
	def ACRelayEnable(self):
                self.game.coils.Solenoidselect.enable()
                self.ACCoilInProgress = False
                print 'nu weer enabled dus voor flashers'
        def test(self):
                self.game.coils.Solenoidselect.enable()
                self.ACCoilInProgress = False
                print 'nu weer enabled dus voor flashers'

	def acCoilPulse(self,coilname,pulsetime=50):
		### Setup variables ###
                self.game.coils.Solenoidselect.disable()
                self.coilname=coilname
                self.pulsetime=pulsetime
		self.ACCoilInProgress = True
		self.acSelectTimeBuffer = .3
		self.acSelectEnableBuffer = (pulsetime/1000)+(self.acSelectTimeBuffer*2)
                print self.acSelectEnableBuffer
		### Remove any scheduling of the AC coils ###
		for item in self.ACNameArray:
			self.game.coils[item].disable()

		### Stop any flashlamp lampshows
		#self.game.lampctrlflash.stop_show()

		### Start the pulse process ###
		#self.cancel_delayed(name='acEnableDelay')
		self.coilfire()
		self.delay(name='coilDelay',event_type=None,delay=self.acSelectTimeBuffer,handler=self.game.coils[coilname].pulse,param=pulsetime)
		self.delay(name='acEnableDelay',delay=self.acSelectEnableBuffer,handler=self.ACRelayEnable)
		self.delay(name='coildelay_temp' , event_type=None, delay=self.acSelectEnableBuffer, handler=self.coilfire)
		
        def coilfire(self):
                self.game.coils[self.coilname].pulse(self.pulsetime)
                print 'nu moet spoel gaan'
                wait=20
                #self.test()
                self.delay(name='test', event_type=None, delay=1, handler=self.test)
  
	def acFlashPulse(self,coilname,pulsetime=70):
		#if (self.ACCoilInProgress == False or coilname not in self.ACNameArray):
                        self.game.coils.Solenoidselect.enable()
			self.game.coils[coilname].pulse(pulsetime)
		#else:
			#Should this try again or just cancel?
			#cannot since the delay function does not allow me to pass more than 1 parameter :(
			#pass

	def acFlashSchedule(self,coilname,schedule=0x09090909,cycle_seconds=1.5,now=True):
		#if (self.ACCoilInProgress == False or coilname not in self.ACNameArray):
                        self.game.coils.Solenoidselect.enable()
			self.game.coils[coilname].disable()
			self.game.coils[coilname].schedule(schedule=schedule, cycle_seconds=cycle_seconds, now=now)
		#else:
			#Should this try again or just cancel?
			#cannot since the delay function does not allow me to pass more than 1 parameter :(
			#pass

##		
##        def set_block(self,value):
##            self.blocking_flag = value
##          
##        def drive(self,name,style='medium',cycle=0,time=2):
##            for i in range(len(self.a_coils)):
##                if name==self.a_coils[i]:
##                    print 'Nu moet een spoel gaan'
##                    
##                    #clear all active devices - the easy way
##                    # if self.switched_flag: #only disable the drives if set as c side
##                    for coil in self.a_coils:
##                        self.game.coils[coil].disable()
##
##                    if name=='outhole':
##                        self.set_block(True)
##
##                    #coil control
##                    self.game.coils.Solenoidselect.disable()
##                    self.switched_flag = False
##                    wait=0.05 #50ms
##                    print name
##                    self.delay(delay=wait,handler=self.game.coils[self.a_coils[i]].pulse)
##                    wait+=0.05
##                    wait+=self.game.coils[self.a_coils[i]].default_pulse_time
##                    self.delay(delay=wait,handler=self.game.coils.Solenoidselect.enable)
##                    self.delay(delay=wait,handler=self.switched_flag_true)
##                    if name=='outhole':
##                         self.delay(delay=wait,handler=lambda:self.set_block(False))
##
##                    self.log.debug('Switched Coil Pulsed:%s',name)
##
##                elif name==self.c_coils[i]:
##
##                    if not self.blocking_flag:
##                        self.game.coils.Solenoidselect.enable()
##                        self.switched_flag = True
##                        self.switch_tries=0
##                        data = [self.a_coils[i],style,cycle,time]
##                        self.flasher(data)
##
####                        self.log.debug('Flasher Scheduled:%s',name)
####                    else:
####                        self.log.debug('Flasher Ingored:%s',name)
##               
##        def switched_flag_true(self):
##                self.switched_flag=True
##        #flasher control - check that ac relay is switched before starting effect
##        #try 10 times before giving up  - TODO - inform ac relay mode that relay is bust in this case
##        def flasher(self,data):
##             #self.log.debug('Switch flag:%s',self.switched_flag)
##             if self.switched_flag:
##                 self.game.effects.drive_flasher(data[0],data[1],data[2],data[3])
##                 self.switch_tries=0
##             elif self.switch_tries<10:
##                 self.delay(name='cside_retry',delay=0.1,handler=self.flasher,param=data)
##                 self.switch_tries+=1
##
##        #disable the drive
##        def disable(self,name):
##            for i in range(len(self.a_coils)):
##                if name==self.a_coils[i] or name==self.c_coils[i]:
##                    self.game.coils[self.a_coils[i]].disable()


##        #switch handlers
##        def sw_csidePower_active(self, sw):
##            self.switched_flag=True
##
##        def sw_csidePower_inactive(self, sw):
##            self.switched_flag=False
