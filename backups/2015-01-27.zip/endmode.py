import procgame
from procgame import *
import locale
from time import time

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class EndMode(game.Mode):
        def __init__(self, game, priority):
            super(endmode, self).__init__(game, priority)

            self.score_layer = dmd.TextLayer(125, 6, self.game.fonts['num_14x10'], "right", opaque=False)
            self.value_layer = dmd.TextLayer(126, 22, self.game.fonts['tiny7'], "right", opaque=False) #07x5

##            self.game.lampctrl.register_show('endmode_lampshow', lampshow_path +"planeten_short.lampshow")

            self.countdown_value = 20

        def mode_started(self):
            print("Debug, endmode Started")
            # start endmode intro
            self.endmode_intro()
            self.display_endmode_layer()
            self.game.sound.fadeout_music(time_ms=2800)

        def mode_stopped(self):
            
            print("Debug, endmode Stopped")

## lamps & animations

        def update_lamps(self):
            

        def display_endmode_layer(self):
             p = self.game.current_player()
             scoreString = locale.format("%d",p.score, True)
             self.score_layer.set_text(scoreString,blink_frames=4)
             self.value_layer.set_text(" TIME LEFT: "+str(locale.format("%d", self.countdown_value, True)))
             self.layer = dmd.GroupedLayer(128, 32, [self.value_layer, self.score_layer])
             self.delay(name='display_endmode_layer', event_type=None, delay=0.1, handler=self.display_endmode_layer)

        def clear_layer(self):
            self.layer = None


## mode functions

        def endmode_intro(self):
            #self.game.sound.play()
            self.game.effects.gi_blinking(cycle_seconds=1)

            #play lightshow
##            self.game.lampctrl.play_show('endmode_lampshow', True, 'None')
            # delay multiballstart to wait for end of lampshow and perhaps animation
            self.delay(name='start_mode', event_type=None, delay=0.5, handler=self.start_mode_3)


        def start_mode_3(self):

             #stop lightshow
             self.game.lampctrl.stop_show()

             #play music
             self.game.sound.play_music('music_starwars_imperial_march')

             #update lamps for entire game after lampshow
             self.delay(name='update_lamps', event_type=None, delay=0.05, handler=self.update_lamps)

             self.countdown()

## switches

        def end_endmode(self):
             print ("debug, No points added")
             self.game.coils.RampLow_EnergyFlash.disable()
             self.game.coils.Solenoidselect.disable()
             # stop music
             self.game.sound.stop_music()
             # cancel delays in case its running
             self.game.sound.play_music('music_starwars_theme')
             self.game.current_player().mode_running = 0
             # remove from mode qeue
             self.game.modes.remove(self)

