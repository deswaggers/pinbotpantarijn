# General play
# all gameplay items that don't belong to a specific mode

import random
import procgame
import locale
import logging
from os import listdir, walk
from os.path import join, splitext
from time import time
from random import randint
from procgame import *

# Dit importeert alle code uit het bestand 'ramprules.py'
from ramprules import *
from bumpers import *
from visor import *
from droptargets import *
from mode1 import *
from mode2 import *
from mode3 import *
#from servo import *

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
plugin_dir = game_path+"plugins/"
speech_path = game_path+"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"
supported_sound = ['.wav', '.aiff', '.ogg', '.mp3']

class Generalplay(game.Mode):

    def __init__(self, game, priority):
        super(Generalplay, self).__init__(game, priority)

        # register modes: hij maakt van de code die onder 'Ramp_rules' staat een object. Het nummer gaat over prioriteit die bv belangrijk is voor animaties:

        #self.ramp_rules = Ramp_rules(self.game, 38)
        self.bumper_rules = Bumpers(self.game, 20)
        self.visor_rules = Visor(self.game, 39)
        self.droptargets = Droptargets(self.game, 40)
        self.game.current_player().mode_lamps = 0
        
        #self.servo_rules = Servo (self.game, 45)
        #self.modes = []
        self.modes = [None, Mode1 (self.game, 19), Mode2 (self.game, 18), Mode3(self.game, 70)]
        #self.register_all_plugins()
        self.start_time = 0

        self.register_all_sounds()
        #register animation layers
##            self.showroom_text = dmd.TextLayer(70, 22, self.game.fonts['07x5'], "center", opaque=False)
##            self.showroom_bgnd = dmd.FrameLayer(opaque=False, frame=dmd.Animation().load(dmd_path+'showroom.dmd').frames[0])
##            self.showroom_layer = dmd.GroupedLayer(128, 32, [self.showroom_bgnd, self.showroom_text])
##            self.showroom_layer.transition = dmd.PushTransition(direction='north')
##
##            self.ramp_text = dmd.TextLayer(70, 23, self.game.fonts['07x5'], "center", opaque=False)

        #register lampshow
        self.game.lampctrl.register_show('rampenter_show', lampshow_path+"rampenter.lampshow")

        self.lamps_ramp = ['megaScore','Rtimelock','Rlock','Rextraball']
        self.willekeurigevariabele=0

    def reset(self):
        pass

    def mode_started(self):
        #self.game.switchedCoils.acFlashSchedule('RampRaise_LowPlFlash')
        #self.game.effects.strobe_controlled_flasher_set(['LowPlFlash'],time=0.3,overlap=0.4,repeats=5)
        # Bij het begin start ie dus de code uit het object ramprules
        startanim = dmd.Animation().load(dmd_path+'intro_starwars.dmd')
        #self.game.modes.add(self.ramp_rules)
        self.game.modes.add(self.bumper_rules)
        self.game.modes.add(self.visor_rules)
        self.game.modes.add(self.droptargets)
        #self.game.modes.add(self.servo_rules)
        if self.game.ball==1:
            self.animation_layer = dmd.AnimatedLayer(frames=startanim.frames, opaque=False, repeat=False, hold=False, frame_time=1)
            self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
            self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)
        self.game.sound.play_music('music_starwars_intro', loops=-1)
        self.game.sound.play('speech_Prepare_to_fire')
        self.game.effects.ramp_down()

    def clear_layer(self):
        self.layer = None

    def start_mode(self, index):
        if not self.game.current_player().mode_running:
            self.game.current_player().mode_running = index
            self.game.modes.add(self.modes[index])
            if self.game.current_player().mode_lamps < 10: self.game.current_player().mode_lamps += 1
            self.update_lamps()
        else:
            print "Mode", index, "werd geprobeerd te starten maar", self.game.current_player().mode_running, "draait al"

    def start_mode_random(self):
        print "Start random mode"
        self.start_mode(randint(1, len(self.modes)-1))

    def register_all_plugins(self):
        modes = []
        for file in listdir(plugin_dir):
            if splitext(file)[1] == '.py':
                modes.append(splitext(file)[0])
        for mode in modes:
            print "REGISTER MODE:", mode
            self.modes.append(getattr(__import__('.plugins', globals(), locals(), [mode]), mode).Mode(self.game))

    def register_all_sounds(self):
        # Register all sounds!
        for (dirpath, dirnames, filenames) in walk(speech_path):
            for filename in filenames:
                if splitext(filename)[1] in supported_sound:
                    sound = "speech_" + splitext(filename)[0].replace(" ", "_")
                    print "SOUND REGISTERED:", sound
                    self.game.sound.register_sound(sound, join(dirpath, filename))

        for (dirpath, dirnames, filenames) in walk(sound_path):
            for filename in filenames:
                if splitext(filename)[1] in supported_sound:
                    sound = "sound_" + splitext(filename)[0].replace(" ", "_")
                    print "SOUND REGISTERED:", sound
                    self.game.sound.register_sound(sound, join(dirpath, filename))

        for (dirpath, dirnames, filenames) in walk(music_path):
            for filename in filenames:
                if splitext(filename)[1] in supported_sound:
                    sound = "music_" + splitext(filename)[0].replace(" ", "_")
                    print "SOUND REGISTERED:", sound
                    self.game.sound.register_music(sound, join(dirpath, filename))

    def mode_stopped(self):
        #self.game.modes.remove(self.ramp_rules)
        self.game.modes.remove(self.bumper_rules)
        self.game.modes.remove(self.visor_rules)
        self.game.modes.remove(self.droptargets)
        #self.game.modes.remove(self.servo_rules)
        print 'generalplay stopped'

    def mode_tick(self):
        pass

## lamps and animations

    def update_lamps(self):
        if self.game.current_player().mode_lamps < 9:
            #pass #de sun moet dan flashen
            # @Jelle: hier even in de if gezet
            for x in range(self.game.current_player().mode_lamps):
                self.game.effects.drive_lamp('planet' + str(x+1), 'on')
                if x < 9: self.game.effects.drive_lamp('planet' + str(x+2), 'medium')
        #Steven (ook kan: if self.game.ramp_move.ramp_up:
        # wel gaan hier problemen komen met modes: als die ook de lampjes willen aansturen....daarnaast gaat de lampupdate niet vaak genoeg
        if self.game.current_player().mode_running:
            self.game.effects.drive_lamp('advance_planet','medium')
        else:
            self.game.effects.drive_lamp('advance_planet','off')

##        def play_spinner(self):
##             # use spinner_turns to select frame, divide with // operator to increase needed turns
##             anim = dmd.Animation().load(dmd_path+'mystery.dmd')
##             self.animation_layer = dmd.FrameLayer(opaque=False, frame=anim.frames[self.spinner_turns//2])
##             self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##             self.delay(name='clear_display', event_type=None, delay=2, handler=self.clear_layer)
##
##        def play_mystery_ready(self):
##            if self.animation_status=='ready':
##                anim = dmd.Animation().load(dmd_path+'mystery_ready.dmd')
##                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=True, hold=False, frame_time=10)
##                self.animation_layer.add_frame_listener(-1, self.clear_layer)
##                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                self.animation_status = 'running'

##        def clear_layer(self):
##             self.layer = None


## mode functions



## Switches regular gameplay
    def sw_shooterLane_open_for_100ms(self,sw):
        self.game.coils.RvisorGI.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
        self.start_time = time()
        self.game.sound.play_music('music_starwars_theme', loops=-1)



    def sw_outhole_active_for_500ms(self, sw):
        self.game.switchedCoils.acCoilPulse('outhole_knocker',45)
        if self.game.switches.Reject.is_active():
            self.game.coils.Rejecthole_SunFlash.pulse(50)
            self.game.coils.Visormotor.enable()
        if self.game.switches.Leject.is_active():
            self.game.coils.Lejecthole_LeftPlFlash.pulse(50)
            self.game.coils.Visormotor.enable()

    def sw_slingL_active(self,sw):
        self.game.switchedCoils.acFlashPulse('RampRaise_LowPlFlash')
        self.game.sound.play("sound_slings")
        self.game.score(100)

    def sw_slingR_active(self,sw):
        self.game.sound.play("sound_slings")
        self.game.switchedCoils.acFlashPulse('RampRaise_LowPlFlash')
        self.game.score(100)

    def sw_Routlane_active(self,sw):
        self.game.sound.play("sound_outlane")
        self.game.score(5000)
        self.game.effects.lower_flashers_flash()
        if time() - 30 < self.start_time:
            print "GRATIS BAL!"
    def sw_Linlane_active(self,sw):
        print "de inlane switch is ingedrukt geweest"
        self.game.sound.play("sound_evil_laugh")
        self.game.score(1000)
        self.game.effects.drive_lamp("Linlane","fast",1.5)

    def sw_Loutlane_active(self,sw):
        self.game.sound.play("sound_outlane")
        self.game.score(5000)
        self.game.effects.lower_flashers_flash()
        if time() - 30 < self.start_time:
            print "GRATIS BAL!"

    def sw_vortex20k_active(self,sw):
        self.clear_layer()
        self.game.sound.play("speech_luke_learntheways")
        self.game.score(2000)

    def sw_vortex100k_active(self,sw):
        self.clear_layer()
        self.game.sound.play("speech_darthvader_yourfather")
        self.game.score(10000)

    def sw_vortex5k_active(self,sw):
        self.clear_layer()
        if self.game.switches.vortex100k.time_since_change()>2 and self.game.switches.vortex20k.time_since_change()>2:
            self.game.sound.play("speech_chewbacca_01")
            self.game.score(500)

    def sw_10point1_active(self,sw):
        self.game.sound.play("sound_hit")
        x=random.random()
        print x
        if x>0.66:
            self.start_mode(3)
        elif x<0.33:
            self.start_mode(2)
        else:
            self.start_mode(1)

    def sw_advanceplanet_active(self, sw):
        self.game.sound.play("sound_hit")
        x=random.random()
        print x
        if x>0.66:
            self.start_mode(3)
        elif x<0.33:
            self.start_mode(2)
        else:
            self.start_mode(1)
        

    def sw_rampexit_active(self, sw):
        self.game.sound.play("sound_ramp_exit")
        self.game.score(10000)

    def sw_flipperLwL_active(self,sw):
        self.game.score(-1000)

    def sw_flipperLwR_active(self,sw):
        self.game.score(-100)

    def sw_startButton_active_for_1s(self, sw):
        if self.game.switches.flipperLwR.is_active(1):
            self.game.effects.release_stuck_balls()
            self.game.coils.Ejecthole_LeftInsBFlash.pulse(30)
            print 'nu moet ejecthole gaan'
