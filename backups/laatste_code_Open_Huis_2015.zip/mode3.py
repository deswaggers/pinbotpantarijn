import procgame
from procgame import *
import locale
from time import time

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Mode3(game.Mode):
        def __init__(self, game, priority):
            super(Mode3, self).__init__(game, priority)

            self.score_layer = dmd.TextLayer(125, 6, self.game.fonts['num_14x10'], "right", opaque=False)
            self.value_layer = dmd.TextLayer(126, 22, self.game.fonts['tiny7'], "right", opaque=False) #07x5

##            self.game.lampctrl.register_show('mode3_lampshow', lampshow_path +"planeten_short.lampshow")

            self.countdown_value = 20

        def mode_started(self):
            print("Debug, Mode3 Started")
            # start mode3 intro
            self.game.sound.play("sound_stormtrooper_laser")
            self.game.score(5000)
            self.mode3_intro()
            self.display_mode3_layer()
            self.game.sound.fadeout_music(time_ms=1000)
            self.game.switchedCoils.acFlashSchedule('RampRaise_LowPlFlash')
            self.game.switchedCoils.acFlashSchedule('Lejecthole_LeftPlFlash')
            self.game.switchedCoils.acFlashSchedule('Drops_RightInsBFlash')

        def mode_stopped(self):
            
            print("Debug, Mode3 Stopped")

## lamps & animations

        def update_lamps(self):
            #self.game.effects.energy_flash(45000/217/10)
                pass

        def display_mode3_layer(self):
             p = self.game.current_player()
             scoreString = locale.format("%d",p.score, True)
             self.score_layer.set_text(scoreString,blink_frames=4)
             self.value_layer.set_text(" TIME LEFT: "+str(locale.format("%d", self.countdown_value, True)))
             self.layer = dmd.GroupedLayer(128, 32, [self.value_layer, self.score_layer])
             self.delay(name='display_mode3_layer', event_type=None, delay=0.1, handler=self.display_mode3_layer)

        def clear_layer(self):
            self.layer = None


## mode functions

        def mode3_intro(self):
            #self.game.sound.play()
            self.game.effects.gi_blinking(cycle_seconds=2)

            #play lightshow
##            self.game.lampctrl.play_show('mode3_lampshow', True, 'None')
            # delay multiballstart to wait for end of lampshow and perhaps animation
            self.delay(name='start_mode', event_type=None, delay=0.5, handler=self.start_mode_3)
	    self.game.effects.drive_lamp('advance_planet')
	    self.game.effects.drive_lamp('solar_energy', 'medium')
	    self.game.effects.drive_lamp('score_energy', 'medium')


        def start_mode_3(self):

             #stop lightshow
             self.game.lampctrl.stop_show()

             #play music
             self.game.sound.play_music('music_starwars_cantina_band')

             #update lamps for entire game after lampshow
             self.delay(name='update_lamps', event_type=None, delay=0.05, handler=self.update_lamps)

             self.countdown()


        def countdown(self):
	     if (self.countdown_value >= 0):
		print ('debug, time left: ', self.countdown_value)
		self.countdown_value -= 1
		##time.sleep(1)
		self.delay(name='countdown', event_type=None, delay=1, handler=self.countdown)
		if self.countdown_value == 0:
                   self.countdown_value = 20
		   self.end_mode3()

	def double_points(self):
	     ## self.game.current_player.score = self.game.current_player.score * 2
	     self.game.score(self.game.current_player().score)

## switches

        def end_mode3(self):
             print ("debug, No points added")
             self.game.coils.RampLow_EnergyFlash.disable()
             # self.game.coils.Solenoidselect.disable()
             # stop music
             self.game.sound.stop_music()
             # cancel delays in case its running
             self.cancel_delayed('countdown')
             self.game.sound.play_music('music_starwars_theme')
             self.countdown_value = 20
             self.game.current_player().mode_running = 0
             # remove from mode qeue
             self.game.modes.remove(self)
	     self.game.effects.drive_lamp('advance_planet', 'medium' )
	     self.game.effects.drive_lamp('solar_energy', 'off')
	     self.game.effects.drive_lamp('score_energy', 'off')

	def sw_rampexit_active(self,sw):
	     self.double_points()
	     self.end_mode3()

	def sw_outhole_active(self,sw):
            print('number balls in play=', self.game.trough.num_balls_in_play)
            self.game.switchedCoils.acCoilPulse('outhole_knocker',45)
            self.end_mode3()
            return procgame.game.SwitchStop
