
import serial
from procgame import *
import locale


class Servo(game.Mode):

        def __init__(self, game, priority):
                super(Servo, self).__init__(game, priority)
                usbport = 'COM8'

                # Set up serial baud rate
                self.ser = serial.Serial(usbport, 9600, timeout=1)
                
        def mode_started(self):
                self.move(1,90)
                self.servo90 = True
                
        def mode_stopped(self):
                pass
        def move(self, servo,angle):
            '''Moves the specified servo to the supplied angle.

            Arguments:
                servo
                  the servo number to command, an integer from 1-4
                angle 
                  the desired servo angle, an integer from 0 to 180

            (e.g.) >>> servo.move(2, 90)
                   ... # "move servo #2 to 90 degrees"'''

            if (0 <= angle <= 180):
                self.ser.write(chr(255))
                self.ser.write(chr(1))
                self.ser.write(chr(angle))
            else:
                print("Servo angle must be an integer between 0 and 180.\n")


        def sw_rampexit_active(self, sw):
                if self.servo90 == True:  
                        self.move(1,180)
                        self.servo90 = False
                else:
                        self.move(1,90)
                        self.servo90 = True


