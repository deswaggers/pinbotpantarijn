# General play
# all gameplay items that don't belong to a specific mode

import procgame
import locale
import logging
from procgame import *
from test_mode import *
from kickback import *
from slings import *
from fase1 import *
from fase2 import *
from fase3 import *
#from mystery import *


# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Generalplay(game.Mode):

        def __init__(self, game, priority):
            super(Generalplay, self).__init__(game, priority)

            #self.mystery = Mystery(self.game, priority+40) # reference to mystery
            
            #register sound effects files
            self.game.sound.register_sound('catapult', sound_path+"bazooka.wav")

            # register modes
            self.kickback_mode = Kickback_mode(self.game, 41)
            self.slings_mode = Slings_mode(self.game, 42)
            self.fase1_mode=Fase1_mode(self.game, 43)
            self.fase1_mode.callback = self.mode_callback
            self.fase2_mode=Fase2_mode(self.game, 44)
            self.fase2_mode.callback = self.mode_callback
            self.fase3_mode=Fase3_mode(self.game, 44)
            self.fase3_mode.callback = self.mode_callback
            
##            #register show
##            self.game.lampctrl.register_show('rampenter_show', lampshow_path+"rampenter.lampshow")
##
##            self.lamps_ramp = ['megaScore','Rtimelock','Rlock','Rextraball']
##            self.frame=0
##            #spinner_count determines the count of each revolution
##            #self.spinner_count = 1 #VIA MENU
##            self.spinner_count = self.game.user_settings['Gameplay (Feature)']['Spinner Count Per Revolution']

        def reset(self):
             pass

        def mode_started(self):
             self.game.modes.add(self.kickback_mode)
             self.game.modes.add(self.slings_mode)
             if self.game.current_player().fase==1 and self.game.ball == 1:
                     self.game.modes.add(self.fase1_mode)
             elif self.game.current_player().fase==2:
                     self.game.modes.add(self.fase2_mode)
             elif self.game.current_player().fase==3:
                     self.game.modes.add(self.fase3_mode)
             elif self.game.current_player().fase==4:
                     self.game.modes.add(self.fase4_mode)
             if self.game.ball == 1:
                     print 'title dmd gestart'
                     anim = dmd.Animation().load(dmd_path+"title.dmd")
                     self.layer = dmd.AnimatedLayer(frames=anim.frames,hold=False,frame_time=14)     


        def mode_stopped(self):
             self.game.modes.remove(self.slings_mode)
             self.game.modes.remove(self.kickback_mode)
             self.game.modes.remove(self.fase1_mode)
             self.game.modes.remove(self.fase2_mode)
             self.game.modes.remove(self.fase3_mode)
             #self.game.modes.remove(self.fase4_mode)
             pass

##      Mode callback
        def mode_callback(self):
             self.game.modes.remove(self.fase1_mode)
             self.game.modes.remove(self.fase2_mode)
             self.game.modes.remove(self.fase3_mode)
             print 'mode_callback gestart'
             if self.game.current_player().fase==1:
                     self.game.modes.add(self.fase1_mode)
             elif self.game.current_player().fase==2:
                     self.game.modes.add(self.fase2_mode)
             elif self.game.current_player().fase==3:
                     self.game.modes.add(self.fase3_mode)
             elif self.game.current_player().fase==4:
                     self.game.modes.add(self.fase4_mode)
                     


## lamps and animations

        def play_animation_catapult(self):
##                anim = dmd.Animation().load(dmd_path+'catapult.dmd')
##                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
##                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                self.game.coils.bboxflashers.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GIrelay.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_L.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_R.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)


        def update_lamps(self):
             pass   
##             self.update_miles_lamps()
##             self.update_xball_lamp()
##             #Steven (ook kan: if self.game.ramp_move.ramp_up:
##             # wel gaan hier problemen komen met modes: als die ook de lampjes willen aansturen....daarnaast gaat de lampupdate niet vaak genoeg
##             if self.game.switches.rampRaise.is_active():
##                self.game.effects.drive_lamp('Rtimelock','slow')
##                self.game.effects.drive_lamp('Rlock','off')
##             else:
##                self.game.effects.drive_lamp('Rtimelock','off')
##                self.game.effects.drive_lamp('Rlock','slow')
##             if not self.mystery_ready:
##                self.game.effects.drive_lamp('bonusholdWL','slow')
##             else:
##                self.game.effects.drive_lamp('Ctimelock','slow')


        def update_xball_lamp(self):
             # update extraball lamp if player has extra ball
             if self.game.current_player().extra_balls:
                  self.game.effects.drive_lamp('cruiseAgain','on')
             else:
                  self.game.effects.drive_lamp('cruiseAgain','off')

##        def play_spinner(self):
##             # use spinner_turns to select frame, divide with // operator to increase needed turns
##             anim = dmd.Animation().load(dmd_path+'mystery.dmd')
##             self.animation_layer = dmd.FrameLayer(opaque=False, frame=anim.frames[self.spinner_turns//2])
##             self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##             self.delay(name='clear_display', event_type=None, delay=2, handler=self.clear_layer)
##
##        def play_mystery_ready(self):
##            if self.animation_status=='ready':
##                anim = dmd.Animation().load(dmd_path+'mystery_ready.dmd')
##                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=True, hold=False, frame_time=10)
##                self.animation_layer.add_frame_listener(-1, self.clear_layer)
##                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                self.animation_status = 'running'
               

        def clear_layer(self):
             self.layer = None
             self.animation_status = 'ready'


## mode functions


        def check_extra_ball(self):
             if self.game.get_player_stats('extraball_on'):
                 # collect extra ball
                 self.game.extra_ball.collect()

## Switches regular gameplay

        def sw_outhole_active_for_500ms(self, sw):
             self.game.coils.outhole.pulse(40)

        def sw_slingL_active(self,sw):
             self.game.score(100)
             self.game.coils.slingL.pulse(40)

        def sw_slingR_active(self,sw):
             self.game.score(100)
             self.game.coils.slingR.pulse(40)
        

        def sw_Lhole_active_for_250ms(self,sw):
             self.game.effects.kickout_Lhole()
        def sw_Rhole_active_for_250ms(self,sw):
             self.game.effects.kickout_Rhole()
        def sw_Lcannon_active_for_250ms(self,sw):
             self.game.effects.kickout_Lcannon()
             self.play_animation_catapult()
             self.game.sound.play("catapult")
        def sw_Rcannon_active_for_250ms(self,sw):
             self.game.effects.kickout_Rcannon()
             self.play_animation_catapult()
             self.game.sound.play("catapult")
        def sw_railup_active_for_250ms(self,sw):
             self.game.effects.kickout_railup()


        def sw_outlaneR_active(self,sw):
             self.game.sound.play("outlanes")
             self.game.score(25000)
##             # geluid nog te doen
##             if self.game.trough.num_balls_in_play==1 and self.game.ball_save.timer==0:
##                 anim = dmd.Animation().load(dmd_path+'crash.dmd')
##                 self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=7)
##                 self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                 self.delay(name='clear_layer', event_type=None, delay=3, handler=self.clear_layer)
