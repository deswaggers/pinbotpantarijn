# Fase 3
import procgame
from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Fase3_mode(game.Mode):
        def __init__(self, game, priority):
                super(Fase3_mode, self).__init__(game, priority)
   
                #self.game.sound.register_sound('thatseasy', speech_path+"geluid1.ogg")
                self.game.sound.register_music('knights_of', music_path+"Monty Python Knights Of The Round Table.mp3")
                
                self.score_layer = dmd.TextLayer(8, 1, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
                self.time_layer = dmd.TextLayer(90, 17, self.game.fonts['num_14x10'], "center", opaque=False)


        def mode_started(self):
                print("Debug, fase3_mode Started")
                self.game.sound.play_music('knights_of', loops=-1)
                self.targetscomplete=False
                self.target_count=0
                
                
                self.LguardM=False
                self.LguardMR=False
                self.LguardR=False
                self.RguardM=False
                self.RguardML=False
                self.RguardL=False

##Nieuwe targets laag
                self.LguardML=False
                self.LguardL=False
                
                self.RguardR=False
                self.RguardMR=False                
                
                self.update_lamps()
                


        def mode_stopped(self):
                self.callback()
                print("Debug, fase3_mode Stopped")



## lamps & animations

        def update_lamps(self):
                if self.LguardM==False:
                        self.game.effects.drive_lamp('LguardM','medium')
                else:
                        self.game.effects.drive_lamp('LguardM','on')
                if self.LguardMR==False:
                        self.game.effects.drive_lamp('LguardMR','medium')
                else:
                        self.game.effects.drive_lamp('LguardMR','on')
                if self.LguardR==False:
                        self.game.effects.drive_lamp('LguardR','medium')
                else:
                        self.game.effects.drive_lamp('LguardR','on')
                if self.RguardM==False:
                        self.game.effects.drive_lamp('RguardM','medium')
                else:
                        self.game.effects.drive_lamp('RguardM','on')
                if self.RguardML==False:
                        self.game.effects.drive_lamp('RguardML','medium')
                else:
                        self.game.effects.drive_lamp('RguardML','on')
                if self.RguardL==False:
                        self.game.effects.drive_lamp('RguardL','medium')
                else:
                        self.game.effects.drive_lamp('RguardL','on')

## Nieuwe deel targets laag
                if self.LguardML==False:
                        self.game.effects.drive_lamp('LguardML','medium')
                else:
                        self.game.effects.drive_lamp('LguardML','on')
                if self.LguardL==False:
                        self.game.effects.drive_lamp('LguardL','medium')
                else:
                        self.game.effects.drive_lamp('LguardL','on')
                if self.RguardR==False:
                        self.game.effects.drive_lamp('RguardR','medium')
                else:
                        self.game.effects.drive_lamp('RguardR','on')
                if self.RguardMR==False:
                        self.game.effects.drive_lamp('RguardMR','medium')
                else:
                        self.game.effects.drive_lamp('RguardMR','on')

                        
                if self.targetscomplete==True:
                        self.game.lamps.LholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                        self.game.lamps.LholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                        self.game.lamps.RholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                        self.game.lamps.RholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                        self.game.lamps.railup.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                else:
                        self.game.effects.drive_lamp('LholeT','off')
                        self.game.effects.drive_lamp('LholeB','off')
                        self.game.effects.drive_lamp('RholeT','off')
                        self.game.effects.drive_lamp('RholeB','off')
                        self.game.effects.drive_lamp('railup','off')




        def play_animation_end(self):
              anim = dmd.Animation().load(dmd_path+'rings.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])#, self.title_layer, self.time_layer
              self.delay(name='clear_layer', event_type=None, delay=10, handler=self.clear_layer)
              self.game.lampctrl.register_show('fase1_show', lampshow_path +"attract/fase1.lampshow")
              self.game.lampctrl.play_show('fase1_show', repeat=False)


        def play_animation_castle(self):
              print "het aantal targets geraakt van de 10 is: ",self.target_count
              self.score_layer = dmd.TextLayer(112, 24, self.game.fonts['num_09Bx7'], "center", opaque=False)
              self.score_layer.set_text(text=str(self.target_count*1000),seconds=1, blink_frames=4)
              anim = dmd.Animation().load(dmd_path+'castle.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[(self.target_count*9-9):(self.target_count*9)], opaque=False, repeat=False, hold=True, frame_time=4)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.score_layer])
              self.cancel_delayed('clear_layer')
              self.delay(name='clear_layer', event_type=None, delay=5, handler=self.clear_layer)

              self.animation_layer.add_frame_listener(7, self.test_message)
        def test_message(self):
              print "Framelistener uitgevoerd."
        def clear_layer(self):
             self.layer = None

        def empty_Lhole(self):
                self.game.effects.kickout_Lhole()
                self.game.modes.remove(self)
        def empty_Rhole(self):
                self.game.effects.kickout_Rhole()
                self.game.modes.remove(self)
        def empty_railup(self):
                self.game.effects.kickout_railup()
                self.game.modes.remove(self)

## Mode functions
             
        def fase_3_done(self):
                self.game.current_player().fase=1
                self.game.sound.fadeout_music(time_ms = 2800)

        def sw_shooterLane_inactive_for_1500ms(self, sw):
                self.game.effects.empty_all_holes()

## switches


        def sw_Lhole_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_3_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        self.delay(name='empty_Lhole', event_type=None, delay=3, handler=self.empty_Lhole)
                        return procgame.game.SwitchStop
                
        def sw_Rhole_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_3_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        self.delay(name='empty_Rhole', event_type=None, delay=3, handler=self.empty_Rhole)
                        return procgame.game.SwitchStop
        
        def sw_railup_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_3_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        self.delay(name='empty_railup', event_type=None, delay=3, handler=self.empty_railup)
                        return procgame.game.SwitchStop

## targets
        def targets_check(self):
                if self.LguardM==True and self.LguardMR==True and self.LguardR==True and self.RguardM==True and self.RguardML==True and self.RguardL==True and self.LguardML==True and self.LguardL==True and self.RguardR==True and self.RguardMR==True:
                        self.targetscomplete=True
                self.game.score(self.target_count*1000)
                self.play_animation_castle()

        def sw_LguardM_active(self,sw):
                self.game.score(100)
                if self.LguardM==False:
                        self.LguardM=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
                        
                

        def sw_LguardMR_active(self,sw):
                self.game.score(100)
                if self.LguardMR==False:
                        self.LguardMR=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
                

        def sw_LguardR_active(self,sw):
                self.game.score(100)
                if self.LguardR==False:
                        self.LguardR=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()


        def sw_RguardM_active(self,sw):
                self.game.score(100)
                if self.RguardM==False:
                        self.RguardM=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()


        def sw_RguardML_active(self,sw):
                self.game.score(100)
                if self.RguardML==False:
                        self.RguardML=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
                       

        def sw_RguardL_active(self,sw):
                self.game.score(100)
                if self.RguardL==False:
                        self.RguardL=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
                
        def sw_LguardML_active(self,sw):
                self.game.score(100)
                if self.LguardML==False:
                        self.LguardML=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
        def sw_LguardL_active(self,sw):
                self.game.score(100)
                if self.LguardL==False:
                        self.LguardL=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
        def sw_RguardR_active(self,sw):
                self.game.score(100)
                if self.RguardR==False:
                        self.RguardR=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()
        def sw_RguardMR_active(self,sw):
                self.game.score(100)
                if self.RguardMR==False:
                        self.RguardMR=True
                        self.target_count+=1
                        self.targets_check()
                self.update_lamps()

        
        def sw_outhole_active(self,sw):
                if self.game.trough.num_balls_in_play==1:
                        self.game.sound.fadeout_music()



