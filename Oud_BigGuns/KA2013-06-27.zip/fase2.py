# Fase 2
import procgame
from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Fase2_mode(game.Mode):
        def __init__(self, game, priority):
                super(Fase2_mode, self).__init__(game, priority)
   
                self.game.sound.register_sound('stab', speech_path+"sword.mp3")
                self.game.sound.register_music('horse', sound_path+"Galloping_Horse.wav")
                
                self.title_layer = dmd.TextLayer(128/1.5, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
                self.time_layer = dmd.TextLayer(90, 17, self.game.fonts['num_14x10'], "center", opaque=False)


        def mode_started(self):
                print("Debug, fase2_mode Started")
                self.game.sound.play_music('horse', loops=-1)
                self.targetscomplete=False
                self.targets=0
                self.LguardM=False
                self.LguardMR=False
                self.LguardR=False
                self.RguardM=False
                self.RguardML=False
                self.RguardL=False
                self.update_lamps()
                


        def mode_stopped(self):
                self.game.effects.drive_lamp('LholeT','off')
                self.game.effects.drive_lamp('LholeB','off')
                self.game.effects.drive_lamp('RholeT','off')
                self.game.effects.drive_lamp('RholeB','off')
                self.game.effects.drive_lamp('railup','off')
                self.callback()
                print("Debug, fase2_mode Stopped")



## lamps & animations

        def update_lamps(self):
                if self.LguardM==False:
                        self.game.effects.drive_lamp('LguardM','medium')
                else:
                        self.game.effects.drive_lamp('LguardM','on')
                if self.LguardMR==False:
                        self.game.effects.drive_lamp('LguardMR','medium')
                else:
                        self.game.effects.drive_lamp('LguardMR','on')
                if self.LguardR==False:
                        self.game.effects.drive_lamp('LguardR','medium')
                else:
                        self.game.effects.drive_lamp('LguardR','on')
                if self.RguardM==False:
                        self.game.effects.drive_lamp('RguardM','medium')
                else:
                        self.game.effects.drive_lamp('RguardM','on')
                if self.RguardML==False:
                        self.game.effects.drive_lamp('RguardML','medium')
                else:
                        self.game.effects.drive_lamp('RguardML','on')
                if self.RguardL==False:
                        self.game.effects.drive_lamp('RguardL','medium')
                else:
                        self.game.effects.drive_lamp('RguardL','on')
                if self.targetscomplete==True:
                        self.game.lamps.LholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                        self.game.lamps.LholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                        self.game.lamps.RholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                        self.game.lamps.RholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                        self.game.lamps.railup.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)




        def play_animation_end(self):
              anim = dmd.Animation().load(dmd_path+'stab.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])#, self.title_layer, self.time_layer
              self.delay(name='clear_layer', event_type=None, delay=10, handler=self.clear_layer)
              self.game.sound.play('electricshock',loops=4, fade_ms=1500)
              self.game.coils.bboxflashers.schedule(schedule=0x0a0a0a0a, cycle_seconds=2, now=True)
              self.game.coils.GIrelay.schedule(schedule=0xfffff000, cycle_seconds=3, now=True)
              self.game.coils.GI_L.schedule(schedule=0xfffff000, cycle_seconds=3, now=True)
              self.game.coils.GI_R.schedule(schedule=0xfffff000, cycle_seconds=3, now=True)

        def play_animation_edelen(self):
              anim = dmd.Animation().load(dmd_path+'edelen.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
              #self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)

        def clear_layer(self):
             self.layer = None


## Mode functions
             
        def fase_2_done(self):
                self.game.current_player().fase=3
                self.game.sound.fadeout_music()
                self.delay(name='endmode', event_type=None, delay=4, handler=self.end_mode)
                
        def end_mode(self):
                self.game.trough.launch_balls(1)
                self.game.effects.drive_lamp('LholeT','off')
                self.game.effects.drive_lamp('LholeB','off')
                self.game.effects.drive_lamp('RholeT','off')
                self.game.effects.drive_lamp('RholeB','off')
                self.game.effects.drive_lamp('railup','off')
                self.game.modes.remove(self)
        
## switches


        def sw_Lhole_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_2_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        return procgame.game.SwitchStop
                
        def sw_Rhole_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_2_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        return procgame.game.SwitchStop
        
        def sw_railup_active(self,sw):
                if self.targetscomplete==True:
                        self.fase_2_done()
                        self.game.score(100000)
                        self.play_animation_end()
                        return procgame.game.SwitchStop

## targets
        def targets_check(self):
                if self.LguardM==True and self.LguardMR==True and self.LguardR==True and self.RguardM==True and self.RguardML==True and self.RguardL==True:
                        self.targetscomplete=True
                        self.game.score(1000)
                self.play_animation_edelen()

        def sw_LguardM_active(self,sw):
                self.game.score(100)
                if self.LguardM==False:
                        self.LguardM=True
                        self.targets_check()
                self.update_lamps()
                        
                

        def sw_LguardMR_active(self,sw):
                self.game.score(100)
                if self.LguardMR==False:
                        self.LguardMR=True
                        self.targets_check()
                self.update_lamps()
                

        def sw_LguardR_active(self,sw):
                self.game.score(100)
                if self.LguardR==False:
                        self.LguardR=True
                        self.targets_check()
                self.update_lamps()


        def sw_RguardM_active(self,sw):
                self.game.score(100)
                if self.RguardM==False:
                        self.RguardM=True
                        self.targets_check()
                self.update_lamps()


        def sw_RguardML_active(self,sw):
                self.game.score(100)
                if self.RguardML==False:
                        self.RguardML=True
                        self.targets_check()
                self.update_lamps()
                       

        def sw_RguardL_active(self,sw):
                self.game.score(100)
                if self.RguardL==False:
                        self.RguardL=True
                        self.targets_check()
                self.update_lamps()
                


        def sw_outhole_active(self,sw):
                self.game.sound.fadeout_music()



