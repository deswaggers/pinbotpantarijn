# Fase 1
import procgame
from procgame import *
import locale
import random

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Fase1_mode(game.Mode):
        def __init__(self, game, priority):
                super(Fase1_mode, self).__init__(game, priority)
   
                self.game.sound.register_sound('electricshock', sound_path+"electric.wav")
                self.game.sound.register_sound('argh', sound_path+"argh.ogg")
                self.game.sound.register_music('bagpipes', music_path+"bagpipes.wav")
                self.game.sound.register_music('lake', music_path+"Gvasdnahr - Lake Of Blood.mp3")
                
                self.title_layer = dmd.TextLayer(128/1.5, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
                self.time_layer = dmd.TextLayer(90, 17, self.game.fonts['num_14x10'], "center", opaque=False)
                self.game.lampctrl.register_show('fase1_show', lampshow_path +"attract/fase1-j.lampshow")
                
        def mode_started(self):
                print("Debug, fase1_mode Started")
                self.update_lamps_fase1_mode()
                x=random.random()
                print x
                if x>0.3:
                        self.game.sound.play_music('lake', loops=-1)
                else:
                        self.game.sound.play_music('bagpipes', loops=-1)
                self.game.sound.set_volume(0.3)
                self.game.base_game_mode.generalplay.kickback_mode.update_lamps()


        def mode_stopped(self):
                self.callback()
                print("Debug, fase1_mode Stopped")
                self.game.effects.drive_lamp('LholeT','off')
                self.game.effects.drive_lamp('LholeB','off')
                self.game.effects.drive_lamp('RholeT','off')
                self.game.effects.drive_lamp('RholeB','off')
                self.game.effects.drive_lamp('railup','off')
                self.game.sound.set_volume(0.5)


## lamps & animations

        def update_lamps_fase1_mode(self):
                self.game.lamps.LholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                self.game.lamps.LholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                self.game.lamps.RholeT.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                self.game.lamps.RholeB.schedule(schedule=0xf0f0f0f0, cycle_seconds=0, now=True)
                self.game.lamps.railup.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)


        def play_animation(self):
              anim = dmd.Animation().load(dmd_path+'zwaard_uit_rots.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])#, self.title_layer, self.time_layer
              self.delay(name='clear_layer', event_type=None, delay=8, handler=self.clear_layer)
              self.delay(name='play_sound', event_type=None, delay=1.5, handler=self.play_sound)
              self.game.lampctrl.play_show('fase1_show', repeat=False)
        def play_sound(self):
                self.game.sound.play('electricshock',loops=8, fade_ms=1500)
                print 'geluid spelen gestart'


        def clear_layer(self):
             self.layer = None


## Mode functions
             
        def fase_1_done(self):
                self.game.current_player().fase=2
                self.game.sound.fadeout_music(time_ms = 2500)
                self.game.effects.drive_lamp('LholeT','off')
                self.game.effects.drive_lamp('LholeB','off')
                self.game.effects.drive_lamp('RholeT','off')
                self.game.effects.drive_lamp('RholeB','off')
                self.game.effects.drive_lamp('railup','off')
                

        def empty_Lhole(self):
                self.game.effects.kickout_Lhole()
                self.game.modes.remove(self)
        def empty_Rhole(self):
                self.game.effects.kickout_Rhole()
                self.game.modes.remove(self)
        def empty_railup(self):
                self.game.effects.kickout_railup()
                self.game.modes.remove(self)

## switches


        def sw_Lhole_active_for_300ms(self,sw):
                self.fase_1_done()
                self.game.score(50000)
                self.play_animation()
                self.delay(name='empty_Lhole', event_type=None, delay=6, handler=self.empty_Lhole)
                return procgame.game.SwitchStop
        def sw_Rhole_active_for_300ms(self,sw):
                self.fase_1_done()
                self.game.score(50000)
                self.play_animation()
                self.delay(name='empty_Rhole', event_type=None, delay=6, handler=self.empty_Rhole)
                return procgame.game.SwitchStop
        def sw_railup_active_for_300ms(self,sw):
                self.fase_1_done()
                self.game.score(50000)
                self.play_animation()
                self.delay(name='empty_railup', event_type=None, delay=6, handler=self.empty_railup)
                return procgame.game.SwitchStop


        def sw_outhole_active(self,sw):
                self.game.sound.fadeout_music(time_ms = 800)



