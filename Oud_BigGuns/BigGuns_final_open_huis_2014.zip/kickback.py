# eerste programmeercode VXtra
import procgame
from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Kickback_mode(game.Mode):
        def __init__(self, game, priority):
                super(Kickback_mode, self).__init__(game, priority)

                self.game.sound.register_sound('kickback', sound_path+"kickback.wav")
                self.game.sound.register_sound('slings', sound_path+"slings.aiff")
                self.game.sound.register_sound('electricshock', sound_path+"electricshock.wav")
                self.game.sound.register_sound('horse_short', sound_path+"Galloping_Horse_short.wav")
                self.game.sound.register_sound('gate_open_dicht', sound_path+"gate_open_dicht.wav")

        def mode_started(self):
                print "Eerste code gestart"
                self.uitstel=False
                self.delay(name='dmduitstel', event_type=None, delay=2, handler=self.dmduitstel)

                self.kickbackon()
                self.gateopen()
                self.update_lamps()

        def mode_stopped(self):
                print("Eerste code gestopt")


## Mode functions
        def dmduitstel(self):
                self.uitstel=True
        def kickbackon(self):
                self.kickback=True
                self.game.coils.Ldroptarget.pulse(35)
                self.drops_downL=0
                self.game.sound.play("electricshock")
                self.delay(name='update_lamps', event_type=None, delay=0.3, handler=self.update_lamps)

        def gateopen(self):
                self.gateR=True
                self.game.coils.right_gate.disable()
                self.game.coils.Rdroptarget.pulse(35)
                self.drops_downR=0
                if self.uitstel==True:
                        self.delay(name='update_lamps', event_type=None, delay=0.3, handler=self.update_lamps)
                        anim = dmd.Animation().load(dmd_path+'gate_open.dmd')
                        self.game.sound.play("gate_open_dicht")
                        self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=12)
                        self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
        def play_animation_catapult(self):
                anim = dmd.Animation().load(dmd_path+'catapult2.dmd')
                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
        def play_animation_dragon_beaten(self):
                anim = dmd.Animation().load(dmd_path+'dragon_beaten.dmd')
                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
        
        def play_animation_troll(self):
                anim = dmd.Animation().load(dmd_path+'troll.dmd')
                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                self.game.sound.play("electricshock")
## switches

        def sw_Loutlane_active(self,sw):
                if self.kickback==True:
                        self.game.coils.kickback.pulse(40)
                        self.game.effects.shaker_pulse()
                        self.kickback=False
                        self.play_animation_catapult()
                        self.game.sound.play("kickback")
                else:
                        self.game.score(10)
                        self.game.sound.play("slings")
                self.update_lamps()

        def sw_LdropR_active(self,sw):
                if self.kickback==False:
                        self.drops_downL+=1
                        self.game.score(100)
                        if self.drops_downL==2:
                                self.kickbackon()
                self.update_lamps()

                
        def sw_LdropM_active(self,sw):
                if self.kickback==False:
                        self.drops_downL+=1
                        self.game.score(100)
                        if self.drops_downL==2:
                                self.kickbackon()
                self.update_lamps()
                
        def sw_LdropL_active(self,sw):
                if self.kickback==False:
                        self.drops_downL+=1
                        self.game.score(100)
                        if self.drops_downL==2:
                                self.kickbackon()
                self.update_lamps()
        
        def sw_Routlane_active(self,sw):
                if self.gateR==True:
                        self.delay(name='gate_closing', event_type=None, delay=1, handler=self.game.coils.right_gate.enable)
                        self.game.score(100)
                        self.gateR=False
                        self.update_lamps()
                        self.game.sound.play("gate_open_dicht")
                        anim = dmd.Animation().load(dmd_path+'gate_closing.dmd')
                        self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=12)
                        self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])

        def sw_RdropR_active(self,sw):
                if self.gateR==False:
                        self.drops_downR+=1
                        self.game.score(100)
                        if self.drops_downR==2:
                                self.gateopen()
                self.update_lamps()
                        

                
        def sw_RdropM_active(self,sw):
                if self.gateR==False:
                        self.drops_downR+=1
                        self.game.score(100)
                        if self.drops_downR==2:
                                self.gateopen()
                self.update_lamps()
                
        def sw_RdropL_active(self,sw):
                if self.gateR==False:
                        self.drops_downR+=1
                        self.game.score(100)
                        if self.drops_downR==2:
                                self.gateopen()
                self.update_lamps()

        def sw_Lloop_active(self,sw):
                if self.kickback==True:
                        self.game.coils.Ldroptarget.pulse(35)
                self.play_animation_troll()
                self.game.effects.shaker_pulse_long()
                self.game.score(30000)
                self.game.coils.bboxflashers.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GIrelay.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_L.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_R.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.delay(name='update_lamps', event_type=None, delay=0.5, handler=self.update_lamps)
        def sw_Rloop_active(self,sw):
                if self.gateR==True:
                        self.game.coils.Rdroptarget.pulse(35)
                self.game.sound.play("horse_short")
                self.game.effects.shaker_pulse_long()
                anim = dmd.Animation().load(dmd_path+'knight_on_horse.dmd')
                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=3)
                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                self.game.score(30000)
                self.game.coils.bboxflashers.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GIrelay.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_L.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.game.coils.GI_R.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
                self.delay(name='update_lamps', event_type=None, delay=0.5, handler=self.update_lamps)

        def sw_Rtroll_active(self,sw):
                self.game.score(100000)
                self.game.effects.play_dragon()
                self.game.effects.reset_Rdrop()
        def sw_Ltroll_active(self,sw):
                self.game.score(100000)
                self.play_animation_dragon_beaten()
                self.game.effects.reset_Ldrop()
## Lampen
                
        def update_lamps(self):
                if self.kickback==True:
                        self.game.effects.drive_lamp('kickback','on')
                        self.game.effects.drive_lamp('LdropL','off')
                        self.game.effects.drive_lamp('LdropM','off')
                        self.game.effects.drive_lamp('LdropR','off')
                else:
                        self.game.effects.drive_lamp('kickback','off')
                        self.game.effects.drive_lamp('LdropL','slow')
                        self.game.effects.drive_lamp('LdropM','slow')
                        self.game.effects.drive_lamp('LdropR','slow')
                if self.gateR==True:
                        self.game.effects.drive_lamp('Rgateopen','on')
                        self.game.effects.drive_lamp('RdropL','off')
                        self.game.effects.drive_lamp('RdropM','off')
                        self.game.effects.drive_lamp('RdropR','off')
                else:
                        self.game.effects.drive_lamp('Rgateopen','off')
                        self.game.effects.drive_lamp('RdropL','slow')
                        self.game.effects.drive_lamp('RdropM','slow')
                        self.game.effects.drive_lamp('RdropR','slow')
                        
                if self.game.switches.LdropR.is_active():
                        self.game.effects.drive_lamp('Lround','fast')
                else:
                        self.game.effects.drive_lamp('Lround','off')
                if self.game.switches.RdropL.is_active():
                        self.game.effects.drive_lamp('Rround','fast')
                else:
                        self.game.effects.drive_lamp('Rround','off')
