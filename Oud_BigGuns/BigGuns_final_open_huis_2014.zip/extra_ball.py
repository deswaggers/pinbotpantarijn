# eerste programmeercode VXtra
import procgame
from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Extra_ball_mode(game.Mode):
        
    def __init__(self, game, priority):
        super(Extra_ball_mode, self).__init__(game, priority)
        self.Lextra_ball=False
        self.Rextra_ball=False

    def mode_started(self):
        self.Lextra_ball=False
        self.Rextra_ball=False
        update_lamps()

    def sw_outlaneL_active(self,sw):
        print 'L geraakt'
        if self.Lextra_ball == False:
            self.Lextra_ball == True
        check_extraball()

    def sw_outlaneR_active(self,sw):
        if self.Rextra_ball == False:
            self.Rextra_ball == True
        check_extraball()

    def check_extraball(self):
        update_lamps()
        if self.Lextra_ball == True and self.Rextra_ball == True:
            self.game.trough.launch_balls(1)
            self.Lextra_ball = False
            self.Rextra_ball = False

    def update_lamps(self):
        if self.Lextra==True:
            self.game.effects.drive_lamp('Lextraball','on')
        else:
            self.game.effects.drive_lamp('Lextraball','off')
        if self.Rextra==True:
            self.game.effects.drive_lamp('Rextraball','on')
        else:
            self.game.effects.drive_lamp('Rextraball','off')
