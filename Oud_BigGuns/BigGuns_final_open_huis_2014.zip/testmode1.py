# TestMode1

from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Test_mode_1(game.Mode):
        def __init__(self, game, priority):
                super(Test_mode_1, self).__init__(game, priority)

                self.game.sound.register_sound('slingshot', sound_path+"Sword_clash.wav")
                self.game.sound.register_sound('muur', sound_path+"muur_bouwen_afbreken.wav")

        def mode_started(self):
                print "Eerste code testMode1 gestart"
                self.game.effects.postdown()
                self.post_up_var=0


        def mode_stopped(self):
                print("testMode1 gestopt")


## Mode functions
##        def slingscheck(self):
##                if self.game.current_player().slings >10:
##                        self.game.score(5000)
##                        self.play_animation()
##                else:
##                        self.game.score(5000)
##                        self.play_animation2()
##                self.game.coils.bboxflashers.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
##                        
##                        
####      Animations
##
##        def play_animation(self):
##              self.title_layer = dmd.TextLayer(110, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
##              self.title_layer.set_text(str(5000),True)  
##              anim = dmd.Animation().load(dmd_path+'slings.dmd')
##              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
##              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.title_layer])
##              self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)
##              
##        def play_animation2(self):
##              self.title_layer = dmd.TextLayer(6, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
##              self.title_layer.set_text(str(self.game.current_player().slings),True)  
##              anim = dmd.Animation().load(dmd_path+'slings.dmd')
##              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=3)
##              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.title_layer])
##              self.delay(name='clear_layer', event_type=None, delay=1, handler=self.clear_layer)
##              
##        def clear_layer(self):
##             self.layer = None
##                        
                
## switches

        def sw_wl_active(self,sw):
             self.post_up_var+=1   
             if self.post_up_var==3: 
                     self.game.sound.play("muur")
                     self.game.effects.postup()
                     self.delay(name='postdown', event_type=None, delay=10, handler=self.postdown)
                     self.game.effects.drive_lamp('wl','superfast')
                     anim = dmd.Animation().load(dmd_path+'wall.dmd')
                     self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[10:14], opaque=False, repeat=False, hold=True, frame_time=4)
                     self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                     self.cancel_delayed('clear_layer')
                     self.delay(name='clear_layer', event_type=None, delay=1, handler=self.clear_layer)
                     self.delay(name='wall_down', event_type=None, delay=1.05, handler=self.wall_down)
                     
                     print 'var3'

             if self.post_up_var==1:
                     self.game.sound.play("muur")
                     self.game.effects.drive_lamp('wl','medium')
                     anim = dmd.Animation().load(dmd_path+'wall.dmd')
                     self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[0:5], opaque=False, repeat=False, hold=True, frame_time=4)
                     self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                     self.cancel_delayed('clear_layer')
                     self.delay(name='clear_layer', event_type=None, delay=2.5, handler=self.clear_layer)
                     print 'var1'
             if self.post_up_var==2:
                     self.game.sound.play("muur")
                     self.game.effects.drive_lamp('wl','superfast')
                     anim = dmd.Animation().load(dmd_path+'wall.dmd')
                     self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[5:10], opaque=False, repeat=False, hold=True, frame_time=4)
                     self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
                     self.cancel_delayed('clear_layer')
                     self.delay(name='clear_layer', event_type=None, delay=2.5, handler=self.clear_layer)
                     print 'var2'
        def postdown(self):
             self.game.effects.postdown()
             self.game.sound.play("muur")
             self.post_up_var=0
            
        def clear_layer(self):
            self.layer = None
        
        def wall_down(self):
            anim = dmd.Animation().load(dmd_path+'wall.dmd')
            self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[0:14], opaque=False, repeat=False, hold=False, frame_time=35)
            self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])



## Lampen
                
        def update_lamps(self):
                pass
