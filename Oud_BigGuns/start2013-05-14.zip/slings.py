# Slings

from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Slings_mode(game.Mode):
        def __init__(self, game, priority):
                super(Slings_mode, self).__init__(game, priority)

                self.game.sound.register_sound('slings', sound_path+"slings.aiff")
                self.game.sound.register_sound('electricshock', sound_path+"electricshock.wav")



        def mode_started(self):
                print "Eerste code slings gestart"


        def mode_stopped(self):
                print("Slings gestopt")


## Mode functions
        def slingscheck(self):
                if self.game.current_player().slings >10:
                        self.game.score(100000)
                        self.play_animation()
                        
##      Animations

        def play_animation(self):
              self.title_layer = dmd.TextLayer(128/1.5, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
              self.title_layer.set_text('SLINGS:'+str(self.game.current_player().slings),True)  
              anim = dmd.Animation().load(dmd_path+'knight_defeated.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.title_layer])
              self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)

        def clear_layer(self):
             self.layer = None
                        
                
## switches

        def sw_slingL_active(self,sw):
             self.game.current_player().slings+=1
             print self.game.current_player().slings
             self.slingscheck()

        def sw_slingR_active(self,sw):
             self.game.current_player().slings+=1
             print self.game.current_player().slings
             self.slingscheck()



## Lampen
                
        def update_lamps(self):
                pass
