# eerste programmeercode VXtra

from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Kickback_mode(game.Mode):
        def __init__(self, game, priority):
                super(Kickback_mode, self).__init__(game, priority)

                self.game.sound.register_sound('kickback', sound_path+"kickback.wav")
                self.game.sound.register_sound('slings', sound_path+"slings.aiff")
                self.game.sound.register_sound('electricshock', sound_path+"electricshock.wav")




        def mode_started(self):
                print "Eerste code gestart"
                self.kickbackon()
                self.gateopen()
                self.update_lamps()

        def mode_stopped(self):
                print("Eerste code gestopt")


## Mode functions
        def kickbackon(self):
                self.kickback=True
                self.game.coils.Ldroptarget.pulse(35)
                self.drops_downL=0
                self.game.sound.play("electricshock")

        def gateopen(self):
                self.gateR=True
                self.game.coils.right_gate.disable()
                self.game.coils.Rdroptarget.pulse(35)
                self.drops_downR=0
                
## switches


        def sw_Loutlane_active(self,sw):
                if self.kickback==True:
                        self.game.coils.kickback.pulse(40)
                        self.kickback=False
                        self.game.sound.play("kickback")
                else:
                        self.game.score(10)
                        self.game.sound.play("slings")
                self.update_lamps()

        def sw_LdropR_active(self,sw):
                self.drops_downL+=1
                self.game.score(100)
                if self.drops_downL==2:
                        self.kickbackon()
                self.update_lamps()

                
        def sw_LdropM_active(self,sw):
                self.drops_downL+=1
                self.game.score(100)
                if self.drops_downL==2:
                        self.kickbackon()
                self.update_lamps()
                
        def sw_LdropL_active(self,sw):
                self.drops_downL+=1
                self.game.score(100)
                if self.drops_downL==2:
                        self.kickbackon()
                self.update_lamps()
        
        def sw_Routlane_active(self,sw):
                if self.gateR==True:
                        self.delay(name='gate_open', event_type=None, delay=1, handler=self.game.coils.right_gate.enable)
                        self.game.score(100)
                        self.gateR=False

        def sw_RdropR_active(self,sw):
                self.drops_downR+=1
                self.game.score(100)
                if self.drops_downR==2:
                        self.gateopen()
                self.update_lamps()

                
        def sw_RdropM_active(self,sw):
                self.drops_downR+=1
                self.game.score(100)
                if self.drops_downR==2:
                        self.gateopen()
                self.update_lamps()
                
        def sw_RdropL_active(self,sw):
                self.drops_downR+=1
                self.game.score(100)
                if self.drops_downR==2:
                        self.gateopen()
                self.update_lamps()
                



## Lampen
                
        def update_lamps(self):
                if self.kickback==True:
                        self.game.effects.drive_lamp('kickback','on')
                else:
                        self.game.effects.drive_lamp('kickback','off')
