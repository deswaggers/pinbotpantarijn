# TestRules

from procgame import *
import locale

# all paths
game_path = "C:\P-ROC\pyprocgame-master\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"

class Test_mode_1(game.Mode):
        # __init__ is wat ie sowieso als eerste uitvoert
        def __init__(self, game, priority):
                super(Test_mode_1, self).__init__(game, priority)

                
                self.game.sound.register_sound('slingshot', sound_path+"Sword_clash.wav")

        # modestarted net zo, beetje dubbelop misschien
        def mode_started(self):
                print "Eerste code testrules gestart"

                # stel je wilt een variabele gebruiken in de 'testrules'
                self.ramp_variabele=0


        def mode_stopped(self):
                print("testrules gestopt")



##                        
                
## switches

        def sw_rampenter_active(self,sw):
             self.game.score(5000)
             self.game.coils.TopFlash3.schedule(schedule=0x0f0f0f0f, cycle_seconds=1, now=True)
             self.game.coils.TopFlash4.schedule(schedule=0xf0f0f0f0, cycle_seconds=1, now=True)
             self.ramp_variabele+=1
             print self.ramp_variabele
             if self.ramp_variabele==4:
                     self.game.effects.ramp_up()
                     self.delay(name='clear_layer', event_type=None, delay=10, handler=self.ramp_count_down)
             self.update_lamps()

##                     self.game.sound.play("muur")

##                     anim = dmd.Animation().load(dmd_path+'wall.dmd')
##                     self.animation_layer = dmd.AnimatedLayer(frames=anim.frames[10:14], opaque=False, repeat=False, hold=True, frame_time=4)
##                     self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                     self.cancel_delayed('clear_layer')
##                     self.delay(name='clear_layer', event_type=None, delay=2.5, handler=self.clear_layer)



## Lampen
                
        def update_lamps(self):
                if self.ramp_variabele==4:
                        self.game.effects.drive_lamp('solar_energy','slow')
                elif self.variabele==3:
                        self.game.effects.drive_lamp('solar_energy','medium')
                elif self.variabele==2:
                        self.game.effects.drive_lamp('solar_energy','fast')
                elif self.variabele==1:
                        self.game.effects.drive_lamp('solar_energy','superfast')
                else:
                        self.game.effects.drive_lamp('solar_energy','off')



## Mode functions


        def ramp_count_down(self):
                self.ramp_variabele-=1
                print self.ramp_variabele
                if self.ramp_variabele==0:
                        self.game.effects.ramp_down()
                        self.update_lamps()








                
##        def slingscheck(self):
##                if self.game.current_player().slings >10:
##                        self.game.score(5000)
##                        self.play_animation()
##                else:
##                        self.game.score(1000)
##                        self.play_animation2()
                    
                     
####      Animations

##        def play_animation(self):
##              self.title_lavariabeleyer = dmd.TextLayer(110, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
##              self.title_layer.set_text(str(5000),True)  
##              anim = dmd.Animation().load(dmd_path+'slings.dmd')
##              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=False, frame_time=6)
##              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.title_layer])
##              self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)
##              
##        def clear_layer(self):
##             self.layer = None
