# eerste programmeercode VXtra

from procgame import *
import locale

# all paths
game_path = config.value_for_key_path('game_path')
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Testmode(game.Mode):
        def __init__(self, game, priority):
                super(Testmode, self).__init__(game, priority)
   
                self.game.sound.register_sound('thatseasy', speech_path+"geluid1.ogg")
                self.game.sound.register_music('easyrider_theme', music_path+"muziek1.ogg")
                
                self.title_layer = dmd.TextLayer(128/1.5, 2, self.game.fonts['num_09Bx7'], "center", opaque=False) #num_09Bx7 num_14x10
                self.time_layer = dmd.TextLayer(90, 17, self.game.fonts['num_14x10'], "center", opaque=False)

                self.target=0

                self.time_left=16



        def mode_started(self):
                print("Debug, TestMode Started")
##                self.game.sound.play_music('easyrider_theme', loops=-1)
                self.title_layer.set_text('MODE STARTED')
                self.countdown()
                self.play_animation()
                self.update_lamps_testmode()

        def mode_stopped(self):
                print("Debug, Testmode Stopped")


        def mode_tick(self):
                pass

## lamps & animations

        def update_lamps_testmode(self):
##                if self.spinner==0:
##                        self.game.lamps.bonusholdWL.schedule(schedule=0x0f0f0f0f, cycle_seconds=0, now=True)
                pass


        def play_animation(self):
              anim = dmd.Animation().load(dmd_path+'knight_defeated.dmd')
              self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=6)
              self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer, self.title_layer, self.time_layer])
              self.delay(name='clear_layer', event_type=None, delay=4, handler=self.clear_layer)

        def clear_layer(self):
             self.layer = None


## Mode functions
             
        def countdown(self):
                self.time_layer.set_text('TIME:'+str(self.time_left),True)
                self.time_left-=1
                self.delay(name='countdown', event_type=None, delay=1, handler=self.countdown)
##                if self.time_left==7:
##                        self.game.sound.play('siren')



## switches


        def sw_Lhole_active_for_600ms(self,sw):
                return True

        def sw_outhole_active(self,sw):
                #self.game.sound.fadeout_music()
                pass



