# General play
# all gameplay items that don't belong to a specific mode

import procgame
import locale
import logging
from procgame import *
#from mystery import *


# all paths
game_path = "C:\P-ROC\pyprocgame-dev\games\VXtra_start/"
speech_path = game_path +"sound/speech/"
sound_path = game_path +"sound/fx/"
music_path = game_path +"sound/music/"
dmd_path = game_path +"dmd/"
lampshow_path = game_path +"lampshows/"

class Generalplay(game.Mode):

        def __init__(self, game, priority):
            super(Generalplay, self).__init__(game, priority)

            #self.mystery = Mystery(self.game, priority+40) # reference to mystery
            
            #register sound effects files
            self.game.sound.register_sound('slingshot', sound_path+"slings.aiff")
            
            #register animation layers
##            self.showroom_text = dmd.TextLayer(70, 22, self.game.fonts['07x5'], "center", opaque=False)
##            self.showroom_bgnd = dmd.FrameLayer(opaque=False, frame=dmd.Animation().load(dmd_path+'showroom.dmd').frames[0])
##            self.showroom_layer = dmd.GroupedLayer(128, 32, [self.showroom_bgnd, self.showroom_text])
##            self.showroom_layer.transition = dmd.PushTransition(direction='north')
##
##            self.ramp_text = dmd.TextLayer(70, 23, self.game.fonts['07x5'], "center", opaque=False)

            #register lampshow
            self.game.lampctrl.register_show('rampenter_show', lampshow_path+"rampenter.lampshow")

            self.lamps_ramp = ['megaScore','Rtimelock','Rlock','Rextraball']
            self.frame=0
##            #spinner_count determines the count of each revolution
##            #self.spinner_count = 1 #VIA MENU
##            self.spinner_count = self.game.user_settings['Gameplay (Feature)']['Spinner Count Per Revolution']

        def reset(self):
             pass

        def mode_started(self):
             pass



        def mode_stopped(self):
             pass

        def mode_tick(self):
             pass

## lamps and animations

        def update_lamps(self):
             pass   
##             self.update_miles_lamps()
##             self.update_xball_lamp()
##             #Steven (ook kan: if self.game.ramp_move.ramp_up:
##             # wel gaan hier problemen komen met modes: als die ook de lampjes willen aansturen....daarnaast gaat de lampupdate niet vaak genoeg
##             if self.game.switches.rampRaise.is_active():
##                self.game.effects.drive_lamp('Rtimelock','slow')
##                self.game.effects.drive_lamp('Rlock','off')
##             else:
##                self.game.effects.drive_lamp('Rtimelock','off')
##                self.game.effects.drive_lamp('Rlock','slow')
##             if not self.mystery_ready:
##                self.game.effects.drive_lamp('bonusholdWL','slow')
##             else:
##                self.game.effects.drive_lamp('Ctimelock','slow')


        def update_xball_lamp(self):
             # update extraball lamp if player has extra ball
             if self.game.current_player().extra_balls:
                  self.game.effects.drive_lamp('cruiseAgain','on')
             else:
                  self.game.effects.drive_lamp('cruiseAgain','off')

##        def play_spinner(self):
##             # use spinner_turns to select frame, divide with // operator to increase needed turns
##             anim = dmd.Animation().load(dmd_path+'mystery.dmd')
##             self.animation_layer = dmd.FrameLayer(opaque=False, frame=anim.frames[self.spinner_turns//2])
##             self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##             self.delay(name='clear_display', event_type=None, delay=2, handler=self.clear_layer)
##
##        def play_mystery_ready(self):
##            if self.animation_status=='ready':
##                anim = dmd.Animation().load(dmd_path+'mystery_ready.dmd')
##                self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=True, hold=False, frame_time=10)
##                self.animation_layer.add_frame_listener(-1, self.clear_layer)
##                self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                self.animation_status = 'running'
               

        def clear_layer(self):
             self.layer = None
             self.animation_status = 'ready'


## mode functions


        def check_extra_ball(self):
             if self.game.get_player_stats('extraball_on'):
                 # collect extra ball
                 self.game.extra_ball.collect()

## Switches regular gameplay

        def sw_eject_active_for_1400ms(self, sw):
             self.game.coils.Ejecthole_LeftInsBFlash.pulse(40)

        def sw_outhole_active_for_500ms(self, sw):
             self.game.coils.outhole_knocker.pulse(40)

        def sw_slingL_active(self,sw):
             self.game.sound.play("slingshot")
             self.game.score(100)

        def sw_slingR_active(self,sw):
             self.game.sound.play("slingshot")
             self.game.score(100)

        def sw_Routlane_active(self,sw):
             self.game.sound.play("outlanes")
             self.game.score(25000)
##             # geluid nog te doen
##             if self.game.trough.num_balls_in_play==1 and self.game.ball_save.timer==0:
##                 anim = dmd.Animation().load(dmd_path+'crash.dmd')
##                 self.animation_layer = dmd.AnimatedLayer(frames=anim.frames, opaque=False, repeat=False, hold=True, frame_time=7)
##                 self.layer = dmd.GroupedLayer(128, 32, [self.animation_layer])
##                 self.delay(name='clear_layer', event_type=None, delay=3, handler=self.clear_layer)
